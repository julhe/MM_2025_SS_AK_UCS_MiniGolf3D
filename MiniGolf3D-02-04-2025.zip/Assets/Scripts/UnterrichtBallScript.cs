using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class UnterrichtBallScript : MonoBehaviour
{
    public Transform otherTransform;
    public ForceMode forceMode;

    public int hits;
    Vector3 dragStart;

    void Update()
    {
        

        RaycastHit hit;
        Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit);
        
        if (GetComponent<Rigidbody>().IsSleeping())
        {
            if (Input.GetMouseButton(0))
            {
                // Wenn: erstes mal das mouse button down -> dragStart setzen.
                if(Input.GetMouseButtonDown(0))
                {
                    dragStart = hit.point;
                }
                Debug.DrawLine(dragStart, hit.point, Color.red);
            }

            // Wenn: mouse button up -> dann kraft auf ball.
            if (Input.GetMouseButtonUp(0))
            {
                GetComponent<Rigidbody>().AddForce(dragStart - hit.point, forceMode);

                // Erh�he hits um 1.
                hits += 1;

                // Finde ein Component/Object vom Typen UiManager und rufe die SetScore Methode mit 'hits' als Parameter auf.
                FindObjectOfType<UiManager>().SetScore(hits);
            }
        } 
        

        
    }






    private void FixedUpdate()
    {
        if(GetComponent<Rigidbody>().position.y < -10.0f)
        {
            print("HILFE ICH FALLE!");
        }
   
    }

}